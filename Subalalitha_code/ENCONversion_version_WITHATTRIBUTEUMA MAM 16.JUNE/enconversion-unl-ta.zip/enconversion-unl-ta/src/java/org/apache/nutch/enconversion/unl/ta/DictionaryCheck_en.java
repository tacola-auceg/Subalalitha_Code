package org.apache.nutch.enconversion.unl.ta;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author root
 */
public class DictionaryCheck_en {
	LoadDictionary_en ldict = new LoadDictionary_en();

	public void dict_Tree() {
		ldict.loadDict();
	}
}
